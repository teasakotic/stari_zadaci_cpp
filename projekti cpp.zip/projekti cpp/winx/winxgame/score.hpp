#ifndef SCORE_HPP_INCLUDED
#define SCORE_HPP_INCLUDED

class Score {
private:


public:

    void update(SDL_Event event) {


    }

    void render(SDL_Renderer * renderer) {

    }




};

#endif // SCORE_HPP_INCLUDED
