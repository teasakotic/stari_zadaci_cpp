#include <iostream>
#include "game.hpp"


using namespace std;

int main(int argc, char ** argv)
{


    Game g; /// napravimo objekat
    g.startGame(); /// pokrenemo igru

    return 0;
}

