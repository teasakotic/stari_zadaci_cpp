var class_level =
[
    [ "Level", "class_level.html#a6d2198200659075e411ab260f397376a", null ],
    [ "~Level", "class_level.html#a249eac1e8f19ff44134efa5e986feaca", null ],
    [ "draw", "class_level.html#ac6f4a249f752ad81c8d447c5199ebcfe", null ]
];