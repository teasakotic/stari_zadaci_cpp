var searchData=
[
  ['tile',['Tile',['../class_tile.html#a6d4751f5e4523a166c5ad6f1f76df0cf',1,'Tile::Tile(int x, int y, int w, int h)'],['../class_tile.html#a7380fc4242c1bd4e14df114d37293f86',1,'Tile::Tile(istream &amp;inputStream)']]],
  ['tileset',['Tileset',['../class_tileset.html#a77f06b8e31460a0cbf0bdb9c9327d183',1,'Tileset']]]
];
